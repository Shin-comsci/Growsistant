import 'package:flutter/material.dart';
import '../widgets/bottom_nav_bar.dart';

class homePage extends StatelessWidget{
  const homePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFE8F5C8),
      body: SafeArea(
          child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      "Bubble sedang",
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
                    ),
                    Image.asset('assets/icons/notification_none.png', width: 40, height: 40),
                  ],
                ),
                  const Text(
                    "happy",
                    style: TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  // Image.asset('assets/icons/emote.png', width: 50, height: 50,),

                const SizedBox(height: 20),

                //Gambar tanaman + health===================================
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                      // const SizedBox(height: 8),
                    Image.asset('assets/images/IoT.png',
                        height: 250),
                      const SizedBox(width: 20),

                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const[
                          Text(
                            "Health",
                            style: TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                            ),
                          ),

                          SizedBox(height: 8),
                          Text(
                            "96%",
                            style: TextStyle(
                              fontSize: 40,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      )
                  ],
                ),

                const SizedBox(height: 20),

                //4 fitur controlling ==============

                Expanded(
                    child: GridView.count(
                        crossAxisCount: 2,
                        crossAxisSpacing: 10,
                        mainAxisSpacing: 10,
                        padding: const EdgeInsets.all(12),
                        children: [
                          _buildInfoCard(
                              context, 'Water', '82%', '/water',
                              Image.asset('assets/icons/waterdrop.png', height: 50)
                          ),
                          _buildInfoCard(
                              context, 'Lighting', '32%', '/lighting',
                              Image.asset('assets/icons/lightbulb.png', height: 50)
                          ),
                          _buildInfoCard(
                              context, 'Humidity', '76%', '/humidity',
                              Image.asset('assets/icons/ph-balance.png', height: 50)
                          ),
                          _buildInfoCard(
                              context, 'Temperature', '19°C', '/temperature',
                              Image.asset('assets/icons/thermometer.png', height: 50)
                          ),
                        ],
                    ),
                ),
              ],
          ),
          )
      ),
      bottomNavigationBar: const BottomNavBar(currentIndex: 0),
    );
  }
  
  Widget _buildInfoCard(BuildContext context, String title, String value, String route, Image image){
    return GestureDetector(
      onTap: (){
        Navigator.pushNamed(context, route);
      },
      child: Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        elevation: 4,
        child: Padding(
            padding: const EdgeInsets.all(16),
        child: Stack(
          children: [
            //bagian kiri atas: icon+title

            Align(
              alignment: Alignment.topLeft,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 45, width: 35, child: image),
                  const SizedBox(width: 8),
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                      color: Colors.black87,
                    ),
                  ),
                ],
              ),
            ),

            //BAgian kanan bawah:
            Align(
              alignment: Alignment.bottomRight,
              child: Text(
                value,
                style: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
            ),
          ],
        ),
        ),
      ),
    );
  }
}

